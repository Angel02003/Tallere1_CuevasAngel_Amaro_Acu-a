package Unidad1;

import ucn.StdIn;
import ucn.StdOut;

public class Clase5 {
        public static void main (String[]args) throws IllegalAccessException {


            ListaEstudiante contenedor=new ListaEstudiante(99999);
            MenuPrincipal(contenedor);
        }



        public static void MenuPrincipal(ListaEstudiante contenedor) throws IllegalAccessException {
            boolean menuEstaAcutivo=true;

            while (menuEstaAcutivo){
                StdOut.println("::: Menu Principal:::");
                StdOut.println("[1] buscar estudiante");
                StdOut.println("[2] agregar estudiante");
                StdOut.println("[3] eliminar estudiante");
                StdOut.println("[4] salir");

                String opccionEleguida= StdIn.readLine();

                switch (opccionEleguida){
                    case "1"-> buscarESTUDIANTE(contenedor);
                    case "2"->agregarESTUDIANTE(contenedor);
                    case "3"->eliminarEstudiante(contenedor);
                    case "4"->menuEstaAcutivo=false;
                    default -> StdOut.println("opccion no valida");
                }
                StdOut.println("adios usuario");
            }
        }

        private static void buscarESTUDIANTE(ListaEstudiante contenedor) throws IllegalAccessException {
            StdOut.println("ingrese un rut para buscar al estudiante");
            String rut=StdIn.readLine();
            int posicion=contenedor.buscar(rut);

            if (posicion!=-1){
                ESTUDIANTE estudianteBuscado=contenedor.optener(posicion);

                StdOut.println("nombre:"+estudianteBuscado.getNombre());
                StdOut.println("rut:"+estudianteBuscado.getRut());

            }
        }

        private static void agregarESTUDIANTE(ListaEstudiante contenedor) throws IllegalAccessException {
            StdOut.println("ingrese los datos para ingresar al estudiante");
            StdOut.println("ingrese el nombre del estudiante");
            String nombre=StdIn.readLine();
            StdOut.println("ingrese el rut del estudiante");
            String rut=StdIn.readLine();

            ESTUDIANTE nuevoEstudiante=new ESTUDIANTE(rut,nombre);
            contenedor.agregar(nuevoEstudiante);
        }
        public static void eliminarEstudiante(ListaEstudiante contenedor){
            StdOut.println("ingresa un rut para eliminar al estudainte");
            String rut=StdIn.readLine();
            if (contenedor.eliminar(rut)){
                StdOut.println("el estudiante "+rut+" ah sido eliminado con exito");
            }
        }
    }


