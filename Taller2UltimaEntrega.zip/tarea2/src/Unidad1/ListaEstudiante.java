package Unidad1;

public class ListaEstudiante {

    //se pone la clase que se quiere contener
    private ESTUDIANTE[]arreglo;
    private int cantidadActial;
    private int cantidadMaxima;

    //------------------------------------------------------------------------------------------------------------------------
    // lista
    // throwns IllegalAccessException (no necesariamente va en el publuc elintelij me lo puso)

    public ListaEstudiante(int cantidadMaxima) throws IllegalAccessException {

        if (cantidadMaxima<=0){
            throw new IllegalAccessException("la cantidad maxima no puede ser negativo");
        }
        this.cantidadMaxima=cantidadMaxima;
        this.arreglo=new ESTUDIANTE[this.cantidadMaxima];
        this.cantidadActial=0;
    }
    //-------------------------------------------------------------------------------------------------------------------------
    // buscar


    //el this.arreglo[i] esta buscando en la cantidad actua(0) el rut ingresado
    public int buscar(String rut){
        for (int i = 0; i < this.cantidadActial; i++) {
            if (this.arreglo[i].getRut().equalsIgnoreCase(rut)) {
                return i;
            }
        }
        // el -1  es en caso de que no encontremos la pocicion de busqueda
        return -1;
    }

    //---------------------------------------------------------------------------------------------------------------------------------------------
    //optener
    public ESTUDIANTE optener(int posicio) throws IllegalAccessException {
        if (posicio<0|| posicio>=this.cantidadMaxima){
            throw new IllegalAccessException("la posicion no es valida");
        }

        return this.arreglo[posicio];
    }


    // -------------------------------------------------------------------------------------------------------------------------------------------
    // agregar
    public void agregar(ESTUDIANTE nuevoEstudiante) throws IllegalAccessException {

        //verificar si existe el estudiante
        if (this.buscar(nuevoEstudiante.getRut())!=1){

            throw new IllegalAccessException("el estudiante existe en el sistema");
        }

        // verificar si hay espacio
        if (this.cantidadActial==this.cantidadMaxima){
            throw new IllegalAccessException("el arreblo esta completo");
        }

        //agregar al estudiante
        this.arreglo[this.cantidadActial]=nuevoEstudiante;
        this.cantidadActial++;
    }

    //----------------------------------------------------------------------------------------------------------------------------------------------
    // Eliminar

    public boolean eliminar (String rut){

        //verificar si existe el rut
        int posicion=this.buscar(rut);

        // eliminar si existe el rut
        if (posicion<=0){

            for (int i = posicion; i <this.cantidadActial-1 ; i++) {
                this.arreglo[i]=this.arreglo[i+1]; // corre la posicion ejmepli (si esta en la posicion 5 se corre al 4----- del 3 a 2 ----- de 2 a 1 )

            }
            this.cantidadActial--;
            return true;
        }
        return false;
    }


//.---------------------------------------------------------------------------------------------------------------------------------------------------------
    // get y sett


}
