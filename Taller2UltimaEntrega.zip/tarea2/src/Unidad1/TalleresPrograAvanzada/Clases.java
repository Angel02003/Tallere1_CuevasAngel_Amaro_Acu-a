package Unidad1.TalleresPrograAvanzada;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.text.View;
import java.util.Optional;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Clases {
        public static void main (String[] args) {
            String fileName = "empleados.txt";

            try {
                BufferedReader br = new BufferedReader(new FileReader(fileName));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
                br.close();
            } catch (IOException e) {
                System.err.println("Error al leer el archivo: " + e.getMessage());
            }


        }
    }


