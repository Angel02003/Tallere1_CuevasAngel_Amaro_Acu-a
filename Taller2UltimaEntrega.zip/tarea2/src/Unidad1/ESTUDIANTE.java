package Unidad1;

public class ESTUDIANTE {

    private String rut;
    private  String nombre;



    //-----------------------------------------------------------------------------
    //constructor


    public ESTUDIANTE(String rut, String nombre) {
        this.rut = rut;
        this.nombre = nombre;
    }

    //-------------------------------------------------------------------------------------------
    //get


    public String getRut() {
        return rut;
    }

    public String getNombre() {
        return nombre;
    }

    //-----------------------------------------------------------------------------
    //sett

    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
