package Unidad2.Ejercicio10Ralizacion.Util;

import Unidad2.Ejercicio10Ralizacion.Servis.ISistemaUCN;
import Unidad2.Ejercicio10Ralizacion.Servis.SistemaPorteria;

public class Instalador {

    private ISistemaUCN SistemaPorteria;

    public Instalador() { SistemaPorteria=new SistemaPorteria();}

    public ISistemaUCN instalarSistema(){ return this.SistemaPorteria;}

}
