package Unidad2.Ejercicio10Ralizacion.Servis;

import Unidad1.EjercicioTaller.VideoJuegos;
import Unidad2.Ejercicio10Ralizacion.Model.*;
import ucn.In;

public class SistemaPorteria implements ISistemaUCN{

    ListaPersona listaPersona;

    public SistemaPorteria(){
        listaPersona=new ListaPersona(999);
    }

    @Override
    public boolean agregarFuncinario(String rut, String nombre, String direccion, int edad, String[] diasTrabajados, int cantidadDeHoras) {
        return agregar(new Funcionario(rut,nombre,direccion,edad,diasTrabajados,cantidadDeHoras));
    }

    @Override
    public boolean agregarDocente(String rut, String nombre, String direccion, int edad, String unidadTrabajo, String[] asignaturaImpartida) {
        return agregar(new Docentes(rut,nombre,direccion,edad,unidadTrabajo,asignaturaImpartida));
    }

    @Override
    public boolean agregarEstudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso) {
        return agregar(new Estudiante(rut,nombre,direccion,edad,carrera,anioDeIngreso));
    }



    public boolean agregar(Persona nuevaPersona){
        return listaPersona.agregar(nuevaPersona);
    }


    @Override
    public String buscar(String rut) {

        Persona persona;

        if (estaVacia()){
            return "la lista esta vacia";
        }
        // todo: revisar i++ porque aparece en gri(fori)
        for (int i = 0; i < this.listaPersona.getCantidadActual();i++) {
            persona=listaPersona.optener(i);
            if (persona.getRut().equalsIgnoreCase(rut)) {
                return persona.desplegar();

            }
        }
        return "la persona no fue encontrada";
    }

    @Override
    public String desplegar() {

        if (estaVacia()){
            return "la lista esta vacia";
        }

        Persona persona;
        String respuesa="";

        for (int i = 0; i < listaPersona.getCantidadActual(); i++) {

            persona=listaPersona.optener(i);
            respuesa=persona.desplegar();
        }

        return respuesa;
    }


    // en caso de lectura de archivo siempre va en el Sistema

    public void lecturaDeArchivosVideoJiegos(String nombreArchivo2){

        //VideoJuegos videoJuegos;

        In archivoEntrada2=new In(nombreArchivo2);

        while (!archivoEntrada2.isEmpty()){

            String[] linea2= archivoEntrada2.readLine().split(",");

            String codigo=linea2[0];
            String nombreVideoJuego=linea2[1];
            int precioVideoJuego=Integer.parseInt(linea2[2]);
            String generoVideoJuego=linea2[3];
            String clasificacion=(linea2[4]);
            String desarrollo=linea2[5];
            String plataforma=linea2[6];

          //  VideoJuegos videoJuegos=new VideoJuegos(codigo,nombreVideoJuego,precioVideoJuego,generoVideoJuego,clasificacion,desarrollo,plataforma);

            // this.agregarVideojuego(videoJuegos);

        }
        archivoEntrada2.close();
    }



    boolean estaVacia(){

        if (listaPersona.getCantidadActual()==0){
            return true;
        }
        return false;
    }

}
