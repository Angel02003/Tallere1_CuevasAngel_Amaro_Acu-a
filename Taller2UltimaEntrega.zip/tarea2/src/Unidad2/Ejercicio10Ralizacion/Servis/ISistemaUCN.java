package Unidad2.Ejercicio10Ralizacion.Servis;

import java.io.IOException;

public interface ISistemaUCN {

    // en caso de lectura de archivo --->  (boolean inicarSistema(String listadoCartas) throws IOException;)

    boolean agregarFuncinario(String rut, String nombre, String direccion, int edad, String[] diasTrabajados, int cantidadDeHoras);
    boolean agregarDocente(String rut, String nombre, String direccion, int edad, String unidadTrabajo, String[] asignaturaImpartida);
    boolean agregarEstudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso);

     String buscar(String rut);
     String desplegar();

}
