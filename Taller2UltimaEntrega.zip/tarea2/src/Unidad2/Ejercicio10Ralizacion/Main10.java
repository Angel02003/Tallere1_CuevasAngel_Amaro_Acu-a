package Unidad2.Ejercicio10Ralizacion;

import Unidad2.Ejercicio10Ralizacion.Servis.ISistemaUCN;
import Unidad2.Ejercicio10Ralizacion.Util.Instalador;
import ucn.StdIn;
import ucn.StdOut;

public class Main10 {
    public static void main (String[]args){

        configuracion();
    }

    public static void  configuracion(){

        ISistemaUCN sistema= new Instalador().instalarSistema();
        menuPrincipal(sistema);
    }



    public static void menuPrincipal(ISistemaUCN sistema){


        while (true){
        StdOut.println("bienbenido al menu principal ");
        StdOut.println("[1] para buscar");
        StdOut.println("[2] para listar");
        StdOut.println("[3] para agregar");
        StdOut.println("[4] para salir");
        String opccion= StdIn.readLine();




            if (opccion.equalsIgnoreCase("1")){
                buscar(sistema);
                continue;

            }
            if (opccion.equalsIgnoreCase("2")){
                listar(sistema);
                continue;

            }
            if (opccion.equalsIgnoreCase("3")){
                agregar(sistema);
                continue;

            }
            if (opccion.equalsIgnoreCase("4")){

                break;
            }

        }

        StdOut.println("adios usuario");
    }


    public static void  buscar(ISistemaUCN sistema){

        String encontrado;

        StdOut.println("ingrese el rut a busar");
        String rut=StdIn.readLine();

        encontrado=sistema.buscar(rut);


        StdOut.println(encontrado);


    }



    public static void  listar(ISistemaUCN sistemaUCN){

        String listar="";


        listar=sistemaUCN.desplegar();

        StdOut.println(listar);

    }
    public static void agregar(ISistemaUCN sistema) {

        while (true) {
            StdOut.println(" ingrese a la persona que quiere agregar");
            StdOut.println("[1] para estudiante");
            StdOut.println("[2] para docente ");
            StdOut.println("[3] para funcionario");
            StdOut.println("[4] para regresar");
            String opccion = StdIn.readLine();

            if (opccion.equalsIgnoreCase("1")) {
                estudiante(sistema);

            }
            if (opccion.equalsIgnoreCase("2")) {
            docente(sistema);
            }
            if (opccion.equalsIgnoreCase("3")) {


            }
            if (opccion.equalsIgnoreCase("4")) {
                menuPrincipal(sistema);
            }
            StdOut.println("opccion no valida");
        }
    }

    public static void estudiante (ISistemaUCN sistema) {

        StdOut.println("ingrese el rut de la persona");
        String rut = StdIn.readLine();
        StdOut.println("ingrese el nombre de la persona");
        String nombre = StdIn.readLine();
        StdOut.println("ingrese la direccion de la persona");
        String direccion = StdIn.readLine();
        int edad = verificacionNumerica("ingrese la edad de la persona");
        StdOut.println("ingrese la cerrera");
        String carrera = StdIn.readLine();
        StdOut.println("ingrese el anio de ingreso");
        int anio =verificacionNumerica("anio de ingreso");

        if (sistema.agregarEstudiante(rut, nombre, direccion, edad, carrera, anio)) {

            StdOut.println("se ah ingresado con exito");

        }
    }



    public static void docente(ISistemaUCN sistema) {

        StdOut.println("ingrese el rut de la persona");
        String rut = StdIn.readLine();
        StdOut.println("ingrese el nombre de la persona");
        String nombre = StdIn.readLine();
        StdOut.println("ingrese la direccion de la persona");
        String direccion = StdIn.readLine();
        int edad = verificacionNumerica("ingrese la edad de la persona");
        int horasTrabajadas=verificacionNumerica("horas trabajadas");
        String[] diasQueTrabaja=new String[3];

          // todo: este for es para llenar los dias que trabaja
        for (int i = 0; i < diasQueTrabaja.length; i++) {
            StdOut.println("ingrese los dias trabajado");
          diasQueTrabaja[i]=StdIn.readLine();

        }
        if (sistema.agregarFuncinario(rut,nombre,direccion,edad,diasQueTrabaja,horasTrabajadas)){
            StdOut.println("se guardo con exito");
        }
    }










    public static int verificacionNumerica (String frace){

        while (true){

            StdOut.println(frace);
            String edadComoString=StdIn.readLine();

            if (esNumerico(edadComoString)){

                return Integer.parseInt(edadComoString);
            }
        }
    }

    public static boolean esNumerico(String edadComoString){

        try {
            Integer.parseInt(edadComoString);
            return true;
        }catch (NumberFormatException exception){
            StdOut.println("lo ingresado como ::::"+ edadComoString+"::::::: no es un factor numerico");
        }
        return false;
    }


}
