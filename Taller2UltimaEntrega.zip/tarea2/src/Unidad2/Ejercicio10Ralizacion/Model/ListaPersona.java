package Unidad2.Ejercicio10Ralizacion.Model;

public class ListaPersona {

    private Persona[]arreglo;
    private int cantidadMaxima;
    private int cantidadActual;


    public ListaPersona (int cantidadMaxima){

        this.cantidadMaxima=cantidadMaxima;
        this.arreglo=new Persona[cantidadMaxima];
        this.cantidadActual=0;
    }


    public int buscar(String rut){

        for (int i = 0; i < this.cantidadActual; i++) {
            if (this.arreglo[i].getRut().equalsIgnoreCase(rut)){
                return i;
            }
        }
        return -1;
    }


    public Persona optener(int pocicion){

        return this.arreglo[pocicion];
    }




    public boolean agregar(Persona nuevaPersona){


        this.arreglo[this.cantidadActual]=nuevaPersona;
        this.cantidadActual++;
        return true;
    }


    public boolean eliminar(String rut){

        int eliminar=this.buscar(rut);

        if (eliminar<=0){
            for (int i = 0; i < this.cantidadActual; i++) {

                this.arreglo[i]=this.arreglo[i+1];
            }
            this.cantidadActual--;
            return true;
        }
        return false;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}
