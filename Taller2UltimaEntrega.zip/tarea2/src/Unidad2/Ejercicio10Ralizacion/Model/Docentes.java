package Unidad2.Ejercicio10Ralizacion.Model;

public class Docentes extends Persona {

    private String unidadTrabajo;
    private String[] asignaturaImpartida;


    public Docentes(String rut, String nombre, String direccion, int edad, String unidadTrabajo, String[] asignaturaImpartida) {
        super(rut, nombre, direccion, edad);
        this.unidadTrabajo = unidadTrabajo;
        this.asignaturaImpartida = asignaturaImpartida;
    }

    public String getUnidadTrabajo() {
        return unidadTrabajo;
    }

    public String[] getAsignaturaImpartida() {
        return asignaturaImpartida;
    }

    public void setUnidadTrabajo(String unidadTrabajo) {
        this.unidadTrabajo = unidadTrabajo;
    }

    public void setAsignaturaImpartida(String[] asignaturaImpartida) {
        this.asignaturaImpartida = asignaturaImpartida;
    }

    @Override
    public String desplegar() {
        return  "\n--------------------------------------------------------------------------"+
                " \nel rut del docente es  "+ this.getRut()
                +"\nel nombre del docente es\n  " + getNombre()
                + "\nla dierccion del docente es  "+ this.getDireccion()
                + " \nla edad del docente es  "  + this.getEdad()
                + "\nla unidad de trabajo es  "+this.unidadTrabajo
                + "\nla asignatura impartida  es   "+ this.asignaturaImpartida+
                "\n--------------------------------------------------------------------------";
    }
}
