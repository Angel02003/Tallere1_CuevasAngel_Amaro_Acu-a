package Unidad2.Ejercicio10Ralizacion.Model;

public class Estudiante extends Persona {


    private String carrera;
    private int anioDeIngreso;


    public Estudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso) {
        super(rut, nombre, direccion, edad);
        this.carrera = carrera;
        this.anioDeIngreso = anioDeIngreso;
    }


    public String getCarrera() {
        return carrera;
    }

    public int getAnioDeIngreso() {
        return anioDeIngreso;
    }


    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public void setAnioDeIngreso(int anioDeIngreso) {
        this.anioDeIngreso = anioDeIngreso;
    }

    @Override
    public String desplegar() {
        return   "\n--------------------------------------------------------------------------"+
                "\nel rut del estudiante es  /// "+ this.getRut()
                +"\n//// el nombre del estudiante es ////  "+ getNombre()
                + "\nla dierccion del estudiante es  /// "+ this.getDireccion()
                + "\n la edad del estudiante es   "+this.getEdad()
                + "\nla carrera del estudiante es  "+this.getCarrera()
                + "\nel anio de ingreso es   "+ this.getAnioDeIngreso()+
                "\n--------------------------------------------------------------------------";
    }
}
