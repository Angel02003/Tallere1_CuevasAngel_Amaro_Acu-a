package Unidad2.Ejercicio10Ralizacion.Model;

public class Funcionario extends Persona {

    private String[] diasTrabajados;
    private int cantidadDeHoras;

    public Funcionario(String rut, String nombre, String direccion, int edad, String[] diasTrabajados, int cantidadDeHoras) {
        super(rut, nombre, direccion, edad);
        this.diasTrabajados = diasTrabajados;
        this.cantidadDeHoras = cantidadDeHoras;
    }
    //---------------------------------------------------------------------------------------------------------
    public String[] getDiasTrabajados() {
        return diasTrabajados;
    }

    public int getCantidadDeHoras() {
        return cantidadDeHoras;
    }
//---------------------------------------------------------------------------------------------------------
    public void setDiasTrabajados(String[] diasTrabajados) {
        this.diasTrabajados = diasTrabajados;
    }

    public void setCantidadDeHoras(int cantidadDeHoras) {
        this.cantidadDeHoras = cantidadDeHoras;
    }
    //---------------------------------------------------------------------------------------------------------
    @Override
    public String desplegar() {
        return
                "\n--------------------------------------------------------------------------"
                        +"el rut del funcionarios es \n  "
                + this.getRut() +
                "\n el nombre del funcionarios es   "+ getNombre()+
                "\nla dierccion del funcionarios es  "+ this.getDireccion()+
                "\nla edad del funcionarios es    " + this.getEdad()+
                "\nla canatidad de horas trabajada es "+this.getCantidadDeHoras()+
                "\nel anio de ingreso es  "+ this.diasTrabajados+
                "--------------------------------------------------------------------------";
    }


    public String diasTrabajado(){

        String respuesta="";

        for (int i = 0; i < diasTrabajados.length; i++) {
            respuesta+=this.diasTrabajados[i];
        }
        return respuesta;
    }


}
