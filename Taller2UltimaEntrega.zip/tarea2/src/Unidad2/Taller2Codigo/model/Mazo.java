package Unidad2.Taller2Codigo.model;

public class Mazo {


    private ListaCartas mazo =new ListaCartas(60);



    public Mazo(ListaCartas mazo) {
        this.mazo = mazo;
    }


    public ListaCartas getMazo() {
        return mazo;
    }

    public void setMazo(ListaCartas mazo) {
        this.mazo = mazo;
    }

}
