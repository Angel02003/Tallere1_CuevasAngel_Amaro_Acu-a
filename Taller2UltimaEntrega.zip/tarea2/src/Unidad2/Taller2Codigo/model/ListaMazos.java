package Unidad2.Taller2Codigo.model;

public class ListaMazos {
    private Mazo[]arregloMazo=new Mazo[5];

    private Cartas[]cartaMazo;

    private int cantidadCartas;


    private int cantidadMaximaMazo;
    private int cantidadActualMazo;

    private int cantMaxMazo;


    public ListaMazos(int cantidadMaximaMazo){


        this.cantidadMaximaMazo=cantidadMaximaMazo;
        this.cantMaxMazo = 60;
        this.arregloMazo=new Mazo[cantidadMaximaMazo];
        this.cartaMazo = new Cartas[cantMaxMazo];
        this.cantidadActualMazo=0;
        this.cantidadCartas = 0;
    }

    public Mazo[] getArregloMazo() {
        return arregloMazo;
    }

    public Cartas[] getCartaMazo() {
        return cartaMazo;
    }

    public int getCantidadCartas() {
        return cantidadCartas;
    }

    public int getCantMaxMazo() {
        return cantMaxMazo;
    }


    public int getCantidadMaximaMazo() {
        return cantidadMaximaMazo;
    }

    public int getCantidadActualMazo() {
        return cantidadActualMazo;
    }

    public boolean añadirCarta(Cartas carta){

        this.cartaMazo[cantidadCartas] = carta;
        cantidadCartas++;
        return true;
    }


   // public Cartas optener(String nombre) {

        //for (int i = 0; i < cantidadActualMazo; i++) {
            //Cartas carta = this.arregloMazo[i];

            //if (carta.getNombre().equalsIgnoreCase(nombre)) {
            //    return carta;
            //}
            //}
            // return null;
       // }
//    }


}

