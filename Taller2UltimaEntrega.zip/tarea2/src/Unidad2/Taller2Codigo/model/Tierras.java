package Unidad2.Taller2Codigo.model;

public class Tierras extends Cartas {


    private String color;

    public Tierras(String nombre, String tipocarta, String color) {
        super(nombre, tipocarta);
        this.color = color;
    }
    //--------------------------------------------------------------------------------------------------------------------
    public String getColor() {
        return color;
    }

    @Override
    public String desplegar() {
        return "///////////// carta tierra //////////////// "+"\n"+
                "nombre: "+this.getNombre()+"\n"+
                "tipo: "+ this.getTipocarta()+"\n"+
                "color: "+ this.getColor()+"\n"+
                "///////////////////////////////////////////////";
    }



}
