package Unidad2.Taller2Codigo.model;

public class ListaUsuario {


    private Usuario[] arregloUsuario;
    private int cantidadMaximaUsuario;
    private int cantidadActualUsuario;


    public ListaUsuario(int cantidadMaximaUsuario){

        this.cantidadMaximaUsuario=cantidadMaximaUsuario;
        this.arregloUsuario=new Usuario[cantidadMaximaUsuario];
        this.cantidadActualUsuario=0;
    }

    public int buscar(String nombreUsuario){

        for (int i = 0; i < this.cantidadActualUsuario; i++) {
            if (this.arregloUsuario[i].getNombreDeUsuario().equalsIgnoreCase(nombreUsuario)){
                return i;
            }
        }
        return -1;
    }


    public Usuario obtener(int pocicion){

        return this.arregloUsuario[pocicion];
    }

    public boolean agregar(Usuario nuevoUsuario){


        this.arregloUsuario[this.cantidadActualUsuario]=nuevoUsuario;
        this.cantidadActualUsuario++;
        return true;
    }


    public boolean eliminar(String nombreUsuario){

        int eliminar=this.buscar(nombreUsuario);

        if (eliminar!=0){

            for (int i = 0; i < this.cantidadActualUsuario-1; i++) {
                this.arregloUsuario[i]=this.arregloUsuario[i+1];
            }
            this.cantidadActualUsuario--;
            return true;
        }
        return false;
    }

    public int getCantidadMaximaUsuario() {
        return cantidadMaximaUsuario;
    }

    public int getCantidadActualUsuario() {
        return cantidadActualUsuario;
    }
}
