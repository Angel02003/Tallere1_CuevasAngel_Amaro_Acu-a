package Unidad2.Taller2Codigo.model;

public class Magic extends Cartas{
    private String texto;
    private String manacost;
    private String poder;
    private String vida;
    private String cmc;
    //--------------------------------------------------------------------------------------------------------------------
    public Magic(String nombre, String tipocarta, String texto, String manacost, String poder, String vida, String cmc) {
        super(nombre, tipocarta);
        this.texto = texto;
        this.manacost = manacost;
        this.poder = poder;
        this.vida = vida;
        this.cmc = cmc;
    }
    //--------------------------------------------------------------------------------------------------------------------

    public String getTexto() {
        return texto;
    }

    public String getManacost() {
        return manacost;
    }

    public String getPoder() {
        return poder;
    }

    public String getVida() {
        return vida;
    }

    public String getCmc() {
        return cmc;
    }
    //--------------------------------------------------------------------------------------------------------------------


    public void setTexto(String texto) {
        this.texto = texto;
    }
    public void setManacost(String manacost) {
        this.manacost = manacost;
    }

    public void setPoder(String poder) {
        this.poder = poder;
    }

    public void setVida(String vida) {
        this.vida = vida;
    }

    public void setCmc(String cmc) {
        this.cmc = cmc;
    }


    @Override
    public String desplegar() {


        return "/////////////////// carta Magic/////////////"+"\n"+
                "nombre: "+this.getNombre()+ "    " +"mana cost: " +this.getManacost()+"CMC: "+this.getCmc()+"\n"+
                "tipo de carta: "+ this.getTipocarta()+"\n"+
                "texto: "+ this.getTexto()+"\n"+
                "power: "+this.getPoder()+"/"+"‘Toughness"+this.vida;
    }
}
