package Unidad2.Taller2Codigo.model;

public class Usuario {

    private ListaMazos mazos;
    private String nombreDeUsuario;
    private String contacenia;
    //--------------------------------------------------------------------------------------------------------------------
    public Usuario(String nombreDeUsuario, String contacenia) {
        this.nombreDeUsuario = nombreDeUsuario;
        this.contacenia = contacenia;
        this.mazos=mazos;
    }
    //--------------------------------------------------------------------------------------------------------------------
    public String getNombreDeUsuario() {
        return nombreDeUsuario;
    }

    public String getContacenia() {
        return contacenia;
    }
    //--------------------------------------------------------------------------------------------------------------------
    public void setNombreDeUsuario(String nombreDeUsuario) {
        this.nombreDeUsuario = nombreDeUsuario;
    }

    public void setContacenia(String contacenia) {
        this.contacenia = contacenia;
    }
}
