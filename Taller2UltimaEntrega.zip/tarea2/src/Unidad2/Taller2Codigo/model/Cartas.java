package Unidad2.Taller2Codigo.model;

public abstract class Cartas {
    private String nombre;
    private String tipocarta;
    //--------------------------------------------------------------------------------------------------------------------
    public Cartas(String nombre, String tipocarta) {
        this.nombre = nombre;
        this.tipocarta = tipocarta;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipocarta() {
        return tipocarta;
    }

    //---------------------------------------------------------------------------------------------------------

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTipocarta(String tipocarta) {
        this.tipocarta = tipocarta;
    }

    public abstract String desplegar();


}
