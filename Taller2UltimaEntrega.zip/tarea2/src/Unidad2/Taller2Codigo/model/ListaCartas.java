package Unidad2.Taller2Codigo.model;

public class ListaCartas {



    private Cartas[]arregloCartas;
    private int cantidadMaxima;
    private int cantidadActual;

    //--------------------------------------------------------------------------------------------------------------------
    public ListaCartas(int cantidadMaxima){

        this.cantidadMaxima=cantidadMaxima;
        this.arregloCartas=new Cartas[cantidadMaxima];
        this.cantidadActual=0;
    }



    //--------------------------------------------------------------------------------------------------------------------
    public int buscar(String nombreCarta){

        for (int i = 0; i <this.cantidadActual; i++) {
            if (this.arregloCartas[i].getNombre().equalsIgnoreCase(nombreCarta)){
                return i;
            }
        }
        return -1;
    }
    //--------------------------------------------------------------------------------------------------------------------
    public Cartas optener(int pocicion){

        return this.arregloCartas[pocicion];
    }

    public Cartas obtener(String nombre){

        for (int i = 0; i < cantidadActual; i++){
            Cartas carta =this.arregloCartas[i];

            if (carta.getNombre().equalsIgnoreCase(nombre)){
                return carta;
            }
        }
        return null;
    }
    //--------------------------------------------------------------------------------------------------------------------
    public boolean agregar(Cartas nuevaCarta) {

        this.arregloCartas[this.cantidadActual] = nuevaCarta;
        this.cantidadActual++;
        return true;
    }

    //--------------------------------------------------------------------------------------------------------------------
    public boolean eliminar(String nombre){

        int eliminar=this.buscar(nombre);

        if (eliminar!=0){

            for (int i = 0; i < this.cantidadActual-1; i++) {
                this.arregloCartas[i]=this.arregloCartas[i+1];
            }
            this.cantidadActual++;
            return true;
        }
        return false;
    }


    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public Cartas[] getArregloCartas() {
        return arregloCartas;
    }

}
