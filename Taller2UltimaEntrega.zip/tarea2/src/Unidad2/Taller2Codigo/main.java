package Unidad2.Taller2Codigo;

import Unidad2.Taller2Codigo.model.*;
import Unidad2.Taller2Codigo.servis.ISistemaMagic;
import Unidad2.Taller2Codigo.util.Instalador;
import ucn.StdIn;
import ucn.StdOut;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class main {
    public static void main(String[]args) throws IOException {

        configuracion();

    }




    public static void  configuracion() throws IOException {



        ISistemaMagic sistemaMagic = new Instalador().sistemaAHinstalar();
        String cartas = "magic.txt";
        String tierras = "tierras.txt";
        String usuarios = "Usuarios.txt";

        boolean lecturaMagic = sistemaMagic.lecturaDeArchivo2(cartas);
        boolean lecturaTierras = sistemaMagic.lecturaDeArchivo1(tierras);
        boolean lecturaUsuarios = sistemaMagic.lecturaDeArchivo3(usuarios);


        menuPrincipal(sistemaMagic);

    }


    public static void menuPrincipal(ISistemaMagic sistemaMagic) throws IOException {

        ListaUsuario listaUsuario = null;

        while (true) {
            StdOut.println("///////////// bienbrnido al menu principal /////////");
            StdOut.println("[1] para iniciar secion");
            StdOut.println("[2] registrace");
            StdOut.println("[3] salir");
            String opccion = StdIn.readLine();

            if (opccion.equalsIgnoreCase("1")) {
                iniciarSecion(sistemaMagic);
            }
            if (opccion.equalsIgnoreCase("2")) {


                StdOut.println("ingrese el nombre de ususario");
                String nombreDeUsuario=StdIn.readLine();
                StdOut.println("ingrese la contrasenia");
                String contracenia=StdIn.readLine();

                if (sistemaMagic.registrarce(nombreDeUsuario,contracenia)){
                    StdOut.println("el usuario se ah ingresado con exito");
                }

            }
            if (opccion.equalsIgnoreCase("3")) {
                break;
            }

        }
        StdOut.println("adio usuario");
        sistemaMagic.cerrarPrograma();


        }




    //------------------------------------------------------------------------------------------------------------------------
    //todo:opcciones menu 1

    public static void iniciarSecion(ISistemaMagic sistemaMagic){


        StdOut.println("ingrese su nombre de usuario");
        String nombreUsuario=StdIn.readLine();
        StdOut.println("ingrese su contraceña");
        String contraceña=StdIn.readLine();

        if (sistemaMagic.iniciarSecion(nombreUsuario,contraceña)){
            MenuSecundario(sistemaMagic);
        }
    }


//-------------------------------------------------------------------------------------------------------------------------------------
    //todo:opcciones menu 2
    // cuando hay regitro


    public static void MenuSecundario(ISistemaMagic sistemaMagic){

        boolean menu=true;

        while (menu) {
            StdOut.println("******************************************");
            StdOut.println("               Menu Principal             ");
            StdOut.println("******************************************" + "\n");

            StdOut.println("[1] para construir mazo");
            StdOut.println("[2] para ver mis mazos");
            StdOut.println("[3] para buscar carta ");
            StdOut.println("[4] para cerrar secion");
            String opccion = StdIn.readLine();

            if (opccion.equalsIgnoreCase("1")) {
                submenuMazo(sistemaMagic);
            }
            if (opccion.equalsIgnoreCase("2")) {
                verMisMazos(sistemaMagic);
            }
            if (opccion.equalsIgnoreCase("3")) {

                buscarCarta(sistemaMagic);
            }
            if (opccion.equalsIgnoreCase("4")) {

                menu=false;
                break;
            }

        }
    }




    public static void  submenuMazo(ISistemaMagic sistemaMagic){

        boolean verificacion=true;

        while (verificacion){
            StdOut.println("****************************************");
            StdOut.println("          menu de construccion          ");
            StdOut.println("****************************************");

            StdOut.println("ingrese su opccion: ");
            StdOut.println("[1] para crear un mazo nuevo ");
            StdOut.println("[2] para modificar uno existente");
            StdOut.println("[3] para volver al menu anterior");
            String opccion=StdIn.readLine();

            if (opccion.equalsIgnoreCase("1")){
                modificarMazo(sistemaMagic);
            }
            if(opccion.equalsIgnoreCase("2")){
              verMisMazos(sistemaMagic);
            }
            if (opccion.equalsIgnoreCase("3")){

                verificacion=false;
                break;

            }


        }
    }



    public static void verMisMazos(ISistemaMagic sistemaMagic){

        String respuesta="";

        respuesta=sistemaMagic.listar();

        StdOut.println("--------------------------------------------------");
        StdOut.println(respuesta);
        StdOut.println("--------------------------------------------------");
    }



    public static void modificarMazo(ISistemaMagic sistemaMagic) {


        StdOut.println("***************************************************");
        StdOut.println("               Menu de constrccion                 ");
        StdOut.println("***************************************************");


        boolean verificacion=true;

        while (verificacion){

            StdOut.println("[1] añadir carta ");
            StdOut.println("[2] eliminar carta");
            StdOut.println("[3] buscarCarta");
            StdOut.println("[4] modificar siderdboard");
            StdOut.println("[5] volver al menu anteriro");
            String opccion=StdIn.readLine();


            if (opccion.equalsIgnoreCase("1")){

                StdOut.println("ingrese el nombre de la carta que quiere añadir  ");
                    String nombreCartaTierras = StdIn.readLine();

                        // todo: la carta si se añade se puede revisar en el deBug

                      sistemaMagic.añadirCartamazo(1, nombreCartaTierras);



                    StdOut.println("la carta se ah añadido con exito. ");



            }

            if (opccion.equalsIgnoreCase("2")){

                eliminarCarta(sistemaMagic);
            }

            if (opccion.equalsIgnoreCase("3")){
                buscarCarta(sistemaMagic);
            }

            if (opccion.equalsIgnoreCase("4")){
              submenuMazo(sistemaMagic);
            }
            if (opccion.equalsIgnoreCase("5")){
                verificacion=false;
                break;
            }
        }

    }



    public static void  buscarCarta(ISistemaMagic  sistemaMagic){

        String cartaEncontrada;

        StdOut.println("ingrese el nombre de la carta que quiere encontrar");
        String nombrecarta=StdIn.readLine();

        cartaEncontrada=sistemaMagic.buscar(nombrecarta);

        StdOut.println("esta fue la carta que se encontro"+"\n"+cartaEncontrada);
    }



    public static void eliminarCarta(ISistemaMagic sistemaMagic){

        StdOut.println("ingrese el nombre de la carta a eliminar");
        String nombreHaEliminar=StdIn.readLine();

        sistemaMagic.eliminar(nombreHaEliminar);

        StdOut.println("se ah eliminado la carta");

    }
}
