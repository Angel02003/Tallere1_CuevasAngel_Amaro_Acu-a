package Unidad2.Taller2Codigo.util;

import Unidad2.Taller2Codigo.servis.ISistemaMagic;
import Unidad2.Taller2Codigo.servis.SistemaMagic;

public class Instalador{

   ISistemaMagic sistemaMagic;
   // todo: revisar el (IsistemaMagic) no deberia estar alli.
   public Instalador() {this.sistemaMagic= new SistemaMagic();}
    public ISistemaMagic sistemaAHinstalar(){
       return this.sistemaMagic;
    }


}
