package Unidad2.Taller2Codigo.servis;

import Unidad2.Taller2Codigo.model.*;
import ucn.ArchivoEntrada;
import ucn.In;
import ucn.Registro;
import ucn.StdOut;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class SistemaMagic implements ISistemaMagic {

    ListaUsuario listaUsuario;
    ListaMazos listaMazos;
    ListaCartas listaCartas;

    // aqui tenemos los rango de las listas que permitiran guardar los datis que vayan entrando
    public SistemaMagic() {
        listaCartas = new ListaCartas(9999);
        listaMazos = new ListaMazos(9999);
        listaUsuario = new ListaUsuario(9999);
    }


    @Override
    public boolean lecturaDeArchivo1(String tierras) throws IOException {

        ArchivoEntrada arch1 = new ArchivoEntrada(tierras);
        while (!arch1.isEndFile()) {

            Registro reg1 = arch1.getRegistro();
            String nombreTierra = reg1.getString();
            String tipo = reg1.getString();
            String color = reg1.getString();

            Tierras tierras1 = new Tierras(nombreTierra, tipo, color);

            this.listaCartas.agregar(tierras1);
        }
        arch1.close();
        return true;
    }

    @Override
    public boolean lecturaDeArchivo2(String magic) throws IOException {


        In archi2 = new In(magic);


        while (!archi2.isEmpty()) {
            String[] linea2 = archi2.readLine().split(";");

            String nombre = linea2[0];
            String descripccion = linea2[1];
            String manaCost = linea2[2];
            String tipoDeCarta =linea2[3];
            String power = linea2[4];
            String vida = linea2[5];
            String cmd = linea2[6];


            Magic magic1 = new Magic(nombre, tipoDeCarta, descripccion, manaCost, power, vida, cmd);

            this.listaCartas.agregar(magic1);
        }

        archi2.close();
        return true;
    }


    // esta lectura de archivo esta pensada para que al momento de cerrar la secion y volver a iniciar el sistema lea
    // la el Usuario.txt que se tiene  se necesita 2 condiciones
    //todo: 1) tener un file de Usuarios.txt
    // todo: 2)la zona de guardado en cerrar cecion que esta como C:\Users\Pablo Cuevas\IdeaProjects\tarea2\Usuarios.txt
    //         esta tiene que ser una direccion de guardado del propio pc.
    @Override
    public boolean lecturaDeArchivo3(String usuarios) throws IOException {

        ArchivoEntrada arch3 = new ArchivoEntrada(usuarios);
        while (!arch3.isEndFile()) {

            Registro reg1 = arch3.getRegistro();
            String nombre = reg1.getString();
            String contrasenia = reg1.getString();


            Usuario usuario = new Usuario(nombre, contrasenia);

            this.listaUsuario.agregar(usuario);
        }
        arch3.close();
        return true;
    }

// aqui se tiene las conparaciones para que cuando se regstre una persona esta las compare y permita ingresar al main o menu
    @Override
    public boolean iniciarSecion(String nombreDeUsuario, String contraceña) {

        for (int i = 0; i < listaUsuario.getCantidadActualUsuario(); i++) {
            if (listaUsuario.obtener(i).getNombreDeUsuario().equalsIgnoreCase(nombreDeUsuario) &&
                    listaUsuario.obtener(i).getContacenia().equalsIgnoreCase(contraceña)) {

                return true;
            }
        }
        return false;
    }


    // aqui se podra guardar los usuarios nuevos que entren por teclado
    @Override
    public boolean registrarce(String nombreDeUsuario, String contraceña) {

        return agregarUsuario(new Usuario(nombreDeUsuario, contraceña));
    }

    // l momento de cerrar el programa los usuario ingresados seran almacenados
    // en un txt de Usuarios para que no se pierda la informacion al momento de cerrar main
    @Override
    public boolean cerrarPrograma() throws IOException {
        FileWriter archivo=null;
        PrintWriter escritor=null;

        try {
            archivo=new FileWriter("C:\\Users\\Pablo Cuevas\\IdeaProjects\\tarea2\\Usuarios.txt");
            escritor=new PrintWriter(archivo);

            for (int i = 0; i < listaUsuario.getCantidadActualUsuario() ; i++) {
                escritor.println(listaUsuario.obtener(i).getNombreDeUsuario() + "; "+listaUsuario.obtener(i).getContacenia());
            }

        }
        catch (Exception e){
            StdOut.println("Error "+ e.getMessage());
        } finally {
            archivo.close();
        }
        return true;
    }


    public boolean agregarUsuario(Usuario nuevoUsuario) {

        return listaUsuario.agregar(nuevoUsuario);
    }

    @Override
    public boolean añadirCartaTierra(String nombre, String tipocarta, String color) {
        return agregar(new Tierras(nombre, tipocarta, color));
    }


    @Override
    public boolean añadirCartaMagic(String nombre, String tipocarta, String texto, String manacost, String poder, String vida, String cmc) {
        return agregar(new Magic(nombre, tipocarta, texto, manacost, poder, vida, cmc));
    }


    // esta opccion permine añadir y almacena una carta en la lista mazo
    @Override
    public boolean añadirCartamazo(int cantidadCartas, String nombreCarta) {

        this.listaCartas.getArregloCartas();

        Cartas aux = this.listaCartas.obtener(nombreCarta);

        listaMazos.añadirCarta(aux);

        return true;
    }


    @Override
    public boolean eliminar(String nombre) {



        return true;


    }


    public boolean agregar(Cartas nuevaCarta) {

        return listaCartas.agregar(nuevaCarta);
    }

// permite buscar la carta que se quiere encontrar
    @Override
    public String buscar(String nombre) {

        Cartas cartas;

        if (estavacia()) {
            return "la lista esta vacia";
        }

        for (int i = 0; i < listaCartas.getCantidadActual(); i++) {

            cartas = listaCartas.optener(i);
            if (cartas.getNombre().equalsIgnoreCase(nombre)) {
                return cartas.desplegar();
            }
        }
        return "la carta no fue encontrada";
    }


    // se encarga de listar las cartas de los mazos
    @Override
    public String listar() {

        if (estavacia()) {
            return "se encuentra vacia la lista";
        }

        String imprimirCarta="";

        for (int i = 0; i <60; i++) {

            imprimirCarta+=this.listaCartas.optener(i).desplegar();

        }
        return imprimirCarta;
    }



// esto es una verificacion para revisar que la lista ni este vacia si no retornara true para avisar que la lista esta vacia.
    public boolean estavacia(){
        if (listaCartas.getCantidadActual()==0){
            return true;
        }
        return false;

    }

}
