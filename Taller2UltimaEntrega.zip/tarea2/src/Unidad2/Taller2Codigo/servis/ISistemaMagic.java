package Unidad2.Taller2Codigo.servis;

import java.io.IOException;

public interface ISistemaMagic{

  boolean lecturaDeArchivo1(String tierras) throws IOException;
  boolean lecturaDeArchivo2(String magic) throws IOException;
  boolean lecturaDeArchivo3(String usuarios) throws IOException;
  boolean iniciarSecion(String nombreDeUsuario,String contraceña);
  boolean registrarce(String nombreDeUsuario,String contraceña);
  boolean cerrarPrograma() throws IOException;
  boolean añadirCartaTierra(String nombre, String tipocarta, String color);
  boolean añadirCartaMagic(String nombre, String tipocarta, String texto, String manacost, String poder, String vida,String cmc);

  boolean añadirCartamazo(int cantidadCartas, String nombreCarta);

  boolean eliminar(String nombre);
  String buscar(String nombre);

  String listar();



}