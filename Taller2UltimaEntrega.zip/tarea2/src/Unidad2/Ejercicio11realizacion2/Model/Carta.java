package Unidad2.Ejercicio11realizacion2.Model;

public abstract class Carta {


    private String nombre;
    private String presencia;
    private String nivel;
    private String descripccion;

    public Carta(String nombre, String presencia, String nivel, String descripccion) {
        this.nombre = nombre;
        this.presencia = presencia;
        this.nivel = nivel;
        this.descripccion = descripccion;
    }


    public String getNombre() {
        return nombre;
    }

    public String getPresencia() {
        return presencia;
    }

    public String getNivel() {
        return nivel;
    }

    public String getDescripccion() {
        return descripccion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPresencia(String presencia) {
        this.presencia = presencia;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public void setDescripccion(String descripccion) {
        this.descripccion = descripccion;
    }

    public abstract boolean tipoInstancia();

    public abstract String desplegar();

}
