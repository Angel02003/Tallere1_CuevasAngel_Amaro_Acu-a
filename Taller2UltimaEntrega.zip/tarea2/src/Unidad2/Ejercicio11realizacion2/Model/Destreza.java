package Unidad2.Ejercicio11realizacion2.Model;

public class Destreza extends Carta{

    private String instancia;
    private String potencia;
    private String precicion;

    public Destreza(String instancia,String nombre, String presencia, String nivel, String descripccion, String potencia, String precicion) {
        super(nombre, presencia, nivel, descripccion);
        this.instancia=instancia;
        this.potencia = potencia;
        this.precicion = precicion;
    }

    public String getInstancia() {
        return instancia;
    }

    public String getPotencia() {
        return potencia;
    }

    public String getPrecicion() {
        return precicion;
    }

    public void setInstancia(String instancia) {
        this.instancia = instancia;
    }

    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public void setPrecicion(String precicion) {
        this.precicion = precicion;
    }

    @Override
    public boolean tipoInstancia() {
        if (instancia.equalsIgnoreCase("destreza")){
            return true;
        }
        return false;
    }

    @Override
    public String desplegar() {
        return " ////////////////  las destreza son //////////////"+
                "la intasncia es "+ this.getInstancia()+"\n"+
                "el nombre es " +this.getNombre()+"\n"+
                "la presencia es "+ this.getPresencia()+"\n"+
                "el niel es "+ this.getNivel()+"\n"+
                "la descripccion es "+ this.getDescripccion()+"\n"+
                "la potencia es "+ this.getPotencia()+"\n"+
                "la presicion es "+ this.getPrecicion()+"\n";
    }
}
