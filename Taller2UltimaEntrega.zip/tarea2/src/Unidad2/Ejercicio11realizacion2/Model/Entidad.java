package Unidad2.Ejercicio11realizacion2.Model;

public class Entidad extends Carta{

    private String instancia;
    private String poderFisico;
    private String poderMagico;
    private String resistenciaFisia;
    private String resistenciaMagica;

    public Entidad(String instancia,String nombre, String presencia, String nivel, String descripccion, String poderFisico, String poderMagico, String resistenciaFisia, String resistenciaMagica) {
        super(nombre, presencia, nivel, descripccion);
        this.instancia = instancia;
        this.poderFisico = poderFisico;
        this.poderMagico = poderMagico;
        this.resistenciaFisia = resistenciaFisia;
        this.resistenciaMagica = resistenciaMagica;
    }

    public String getInstancia() {
        return instancia;
    }

    public String getPoderFisico() {
        return poderFisico;
    }

    public String getPoderMagico() {
        return poderMagico;
    }

    public String getResistenciaFisia() {
        return resistenciaFisia;
    }

    public String getResistenciaMagica() {
        return resistenciaMagica;
    }

    public void setInstancia(String instancia) {
        this.instancia = instancia;
    }

    public void setPoderFisico(String poderFisico) {
        this.poderFisico = poderFisico;
    }

    public void setPoderMagico(String poderMagico) {
        this.poderMagico = poderMagico;
    }

    public void setResistenciaFisia(String resistenciaFisia) {
        this.resistenciaFisia = resistenciaFisia;
    }

    @Override
    public boolean tipoInstancia() {
        if (instancia.equalsIgnoreCase("entidad")){
            return true;
        }

        return false;
    }

    @Override
    public String desplegar() {
        return  " ////////////////  las entidades son //////////////"+
                "la intasncia es "+ this.getInstancia()+"\n"+
                "el nombre es " +this.getNombre()+"\n"+
                "la presencia es "+ this.getPresencia()+"\n"+
                "el niel es "+ this.getNivel()+"\n"+
                "la descripccion es "+ this.getDescripccion()+"\n"+
                "el poder fisico es "+ this.poderFisico+"\n"+
                "el poder magico es "+ this.poderMagico+"\n"+
                "la resistencia fisica es "+ this.resistenciaFisia+"\n"+
                "la resistencia magica es "+ this.resistenciaMagica+"\n";
    }
}
