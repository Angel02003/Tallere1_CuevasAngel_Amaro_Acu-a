package Unidad2.Ejercicio11realizacion2.Model;

public class ListaCartas {

    private Carta[]arreglo;
    private int cantidadMaxima;
    private int cantidadActual;



    public ListaCartas(int cantidadMaxima){

        this.cantidadMaxima=cantidadMaxima;
        this.arreglo=new Carta[cantidadMaxima];
        this.cantidadActual=0;
    }



    public int buscar(String nombre){

        for (int i = 0; i < this.cantidadActual; i++) {
            if (this.arreglo[i].getNombre().equalsIgnoreCase(nombre)){
                return i;
            }
        }
        return -1;
    }

    public Carta optener(int posicion){


        return this.arreglo[posicion];
    }


    public boolean agregar (Carta nuevaCarta){

        this.arreglo[this.cantidadActual]=nuevaCarta;
        this.cantidadActual++;
        return true;
    }

    public boolean eliminar(String nombre){

        int eliminar=this.buscar(nombre);

        if (eliminar<=0){

            for (int i = 0; i < this.cantidadActual-1; i++) {
                this.arreglo[i]=this.arreglo[i+1];
            }
            this.cantidadActual++;
            return true;
        }
        return false;

    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}
