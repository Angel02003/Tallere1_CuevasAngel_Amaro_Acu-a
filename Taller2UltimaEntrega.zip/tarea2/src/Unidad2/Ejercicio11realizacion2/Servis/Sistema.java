package Unidad2.Ejercicio11realizacion2.Servis;

import Unidad2.Ejercicio11realizacion2.Model.Destreza;
import Unidad2.Ejercicio11realizacion2.Model.Entidad;
import Unidad2.Ejercicio11realizacion2.Model.ListaCartas;
import ucn.ArchivoEntrada;
import ucn.Registro;

import java.io.IOException;

public class Sistema implements ISistema {

    private ListaCartas listaCartas;

    public Sistema(){listaCartas=new ListaCartas(9999);}

    @Override
    public boolean iniciarSistema(String listaCartas) throws IOException {

        ArchivoEntrada archi1=new ArchivoEntrada(listaCartas);

        while (!archi1.isEndFile()){

            Registro reg1=archi1.getRegistro();
            String intancia=reg1.getString();
            String nombre=reg1.getString();
            String presencia=reg1.getString();
            String nivel=reg1.getString();
            String descripccion=reg1.getString();

            if (intancia.equalsIgnoreCase("entidad")){

                String poderFisico=reg1.getString();
                String poderMagico=reg1.getString();
                String resistenciaFisica=reg1.getString();
                String resistenciaMagica=reg1.getString();

                Entidad entidad=new Entidad(intancia,nombre,presencia,nivel,descripccion,poderFisico,poderMagico,resistenciaFisica,resistenciaMagica);

                this.listaCartas.agregar(entidad);

            }

            if (intancia.equalsIgnoreCase("destreza")){
                String potencia=reg1.getString();
                String precicion=reg1.getString();

                Destreza destreza=new Destreza(intancia,nombre,presencia,nivel,descripccion,potencia,precicion);

                this.listaCartas.agregar(destreza);
            }
        }

        archi1.close();
        return true;
    }






    @Override
    public String listarTodasLasCartas() {
        String imprimirCartas = "";

        for (int i = 0; i < 20; i++) {

            imprimirCartas += this.listaCartas.optener(i).desplegar();
            imprimirCartas += "\n";
        }
        for (int i = 0; i < 20; i++) {
            imprimirCartas += this.listaCartas.optener(i).desplegar();
            imprimirCartas += "\n";
        }
        return imprimirCartas;
    }

    @Override
    public String listarEntiades() {
        String imprimirEntidades = "";

        for (int i = 0; i < 20; i++) {
            imprimirEntidades += this.listaCartas.optener(i).desplegar();
            imprimirEntidades += "\n";
        }
        return imprimirEntidades;
    }

    @Override
    public String listarDestrezas() {
        String imprimirDestrezas = "";

        for (int i = 0; i < 20; i++) {
            imprimirDestrezas += this.listaCartas.optener(i).desplegar();
            imprimirDestrezas += "\n";
        }
        return imprimirDestrezas;
    }
}
