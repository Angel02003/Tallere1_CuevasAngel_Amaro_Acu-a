package Unidad2.Ejercicio11realizacion2.Servis;

import java.io.IOException;

public interface ISistema {

     boolean iniciarSistema(String listaCartas) throws IOException;

    String listarTodasLasCartas();
    String listarEntiades();
    String listarDestrezas();


}
