package Unidad2.Ejercicio11realizacion2.Util;

import Unidad2.Ejercicio11realizacion2.Servis.ISistema;
import Unidad2.Ejercicio11realizacion2.Servis.Sistema;

public class Instalador {

    private ISistema Sisitema;

    public Instalador(){this.Sisitema=new Sistema();}

    public ISistema sistemaAHintalar(){return this.Sisitema;}
}
