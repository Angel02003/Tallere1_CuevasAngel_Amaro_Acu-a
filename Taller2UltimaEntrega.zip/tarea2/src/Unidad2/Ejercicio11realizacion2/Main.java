package Unidad2.Ejercicio11realizacion2;

import Unidad2.Ejercicio11realizacion2.Servis.ISistema;
import Unidad2.Ejercicio11realizacion2.Util.Instalador;
import ucn.StdIn;
import ucn.StdOut;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
      configuracion();
    }


    public static void configuracion() throws IOException {
        String listadoCartas = "listadoCartas.txt";

        ISistema sistema = new Instalador().sistemaAHintalar();
        boolean lectura = sistema.iniciarSistema(listadoCartas);

        menuPrincipa(sistema);
    }


    public static void menuPrincipa(ISistema sistema) {

        while (true) {
            StdOut.println("bienvenido al menu principal");
            StdOut.println("[1] para listar todas las cartas");
            StdOut.println("[2] para listar solo entidades ");
            StdOut.println("[3] para listar solo destrezas");
            StdOut.println("[4] para terminar");
            String opccion = StdIn.readLine();
            if (opccion.equalsIgnoreCase("1")) {
                listarTodasLasCartas(sistema);
            }
            if (opccion.equalsIgnoreCase("2")) {
               listarentidades(sistema);
            }
            if (opccion.equalsIgnoreCase("3")) {
               listarDestresas(sistema);
            }
            if (opccion.equalsIgnoreCase("4")) {
                break;
            }
        }
        StdOut.println("adios ususario");
    }

    public static void listarTodasLasCartas(ISistema sistema){

        String respuesta="";

        respuesta=sistema.listarTodasLasCartas();

        StdOut.println(respuesta);
    }


    public static void listarentidades(ISistema sistema){

        String respuesta="";

        respuesta=sistema.listarEntiades();
        StdOut.println(respuesta);
    }

    public static void listarDestresas(ISistema sistema){

        String respuesta="";

        respuesta=sistema.listarDestrezas();

        StdOut.println(respuesta);

    }



}