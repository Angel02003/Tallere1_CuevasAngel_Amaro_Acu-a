package Unidad2.EjercicioPropuestoClase10.util;

import Unidad2.EjercicioPropuestoClase10.service.ISistemaClase10;
import Unidad2.EjercicioPropuestoClase10.service.SistemaClase10;

public class Instalador {



    ISistemaClase10 sistemaClase10;


    public Instalador (){ this.sistemaClase10=new SistemaClase10();}

    public ISistemaClase10 sistemaAhInstalar(){ return this.sistemaClase10;}

}
