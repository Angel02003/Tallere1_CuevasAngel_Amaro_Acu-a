package Unidad2.EjercicioPropuestoClase10.service;

public interface ISistemaClase10 {




    boolean agregarDocente(String rut, String nombre, String direccion, int edad, String unidadTrabajada, String nombreDeLasCarreras);
    boolean agregarFuncionarios(String rut, String nombre, String direccion, int edad, int horasTrabajadas, String diasTrabajado);
    boolean  agregarEstudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso);

    String buscar(String rut);
    String listar();



}
