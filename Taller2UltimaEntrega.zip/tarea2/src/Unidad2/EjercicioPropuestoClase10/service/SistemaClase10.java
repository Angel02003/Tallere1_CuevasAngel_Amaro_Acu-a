package Unidad2.EjercicioPropuestoClase10.service;

import Unidad2.EjercicioPropuestoClase10.model.Docente;
import Unidad2.EjercicioPropuestoClase10.model.Estudiante;
import Unidad2.EjercicioPropuestoClase10.model.ListaPersonasClase10;
import Unidad2.EjercicioPropuestoClase10.model.Persona;
import ucn.StdOut;

public class SistemaClase10 implements ISistemaClase10{


    ListaPersonasClase10 listaPersonasClase10;


    public  SistemaClase10(){listaPersonasClase10=new ListaPersonasClase10(999);}


    @Override
    public boolean agregarDocente(String rut, String nombre, String direccion, int edad, String unidadTrabajada, String nombreDeLasCarreras) {
        return agregar(new Docente(rut,nombre,direccion,edad,unidadTrabajada,nombreDeLasCarreras));
    }

    @Override
    public boolean agregarFuncionarios(String rut, String nombre, String direccion, int edad, int horasTrabajadas, String diasTrabajado) {
        return agregarFuncionarios(rut,nombre,direccion,edad,horasTrabajadas,diasTrabajado);
    }

    @Override
    public boolean agregarEstudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso) {
        return agregar(new Estudiante(rut,nombre,direccion,edad,carrera,anioDeIngreso));
    }




    @Override
    public String buscar(String rut) {

        Persona persona;

        if (estaVacia()){
            return "la lista esta vacia";
        }

        for (int i = 0; i < listaPersonasClase10.getCantidadaActualPersonas(); i++) {
            persona= listaPersonasClase10.optener(i);
            return persona.listarPersonas();
        }

        return "persona no encontrada ";
    }

    @Override
    public String listar() {

        Persona persona;
        String respuesta=";";

       if (estaVacia()){
           return "la lista esta vacia";
       }

        for (int i = 0; i < listaPersonasClase10.getCantidadaActualPersonas(); i++) {

            persona=this.listaPersonasClase10.optener(i);
            respuesta+=persona.listarPersonas();

        }
        return respuesta;
    }

    public boolean agregar(Persona nuevaPersona){return  this.listaPersonasClase10.agregarPersona(nuevaPersona);}

    public  boolean estaVacia(){

        if (this.listaPersonasClase10.getCantidadaActualPersonas()==0){
            return true;
        }
        return false;
    }



    // lecturaDeArchivo






}
