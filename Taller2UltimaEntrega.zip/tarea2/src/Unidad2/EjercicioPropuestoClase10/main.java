package Unidad2.EjercicioPropuestoClase10;

import Unidad2.Ejercicio10Ralizacion.Servis.ISistemaUCN;
import Unidad2.EjercicioPropuestoClase10.service.ISistemaClase10;
import Unidad2.EjercicioPropuestoClase10.util.Instalador;
import ucn.StdIn;
import ucn.StdOut;

public class main {
    public static void main(String[] args) {

        configuracion();
    }


    public static void configuracion() {

        ISistemaClase10 sistema = new Instalador().sistemaAhInstalar();
      menuPrincipal(sistema);
    }


    public static void menuPrincipal(ISistemaClase10 sistema) {

        while (true) {

            StdOut.println("ingrese una opccion");
            StdOut.println("[1] para buscar personas ");
            StdOut.println("[2] para listar Personas ");
            StdOut.println("[3] para agregar Personas ");
            StdOut.println("[4] para cerrar seccion");
            String opccion = StdIn.readLine();


            if (opccion.equalsIgnoreCase("1")) {
              buscar(sistema);
            }
            if (opccion.equalsIgnoreCase("2")) {
             listar(sistema);
            }
            if (opccion.equalsIgnoreCase("3")) {
              agregar(sistema);
            }
            if (opccion.equalsIgnoreCase("4")) {
                break;
            }
        }
        StdOut.println("adios usuario");
    }


    public static void buscar(ISistemaClase10 sistema) {

        String persona = "";
        StdOut.println("ingrese el rut de la persona");
        String rut = StdIn.readLine();

        persona = sistema.buscar(rut);

        StdOut.println(persona);

    }


    public static void listar(ISistemaClase10 sistema) {

        String persona = "";

        persona = sistema.listar();

        StdOut.println(persona);
    }


    public static void agregar(ISistemaClase10 sistema) {

        while (true){
            StdOut.println("una opccion");
        StdOut.println("[1] agregar docente");
        StdOut.println("[2] agregar duncionario");
        StdOut.println("[3] agregar estudiante");
        StdOut.println("[4] volver al menu principal");
        String opccion = StdIn.readLine();

        if (opccion.equalsIgnoreCase("1")) {
          agregarDocente(sistema);
        }
        if (opccion.equalsIgnoreCase("2")) {
               agregarfuncionario(sistema);
        }
        if (opccion.equalsIgnoreCase("3")) {
         agregarEstudiante(sistema);
        }
        if (opccion.equalsIgnoreCase("4")) {
            break;
        }
    }

}


    public static void agregarDocente(ISistemaClase10 sistema){

        StdOut.println("ingrese el rut");
        String rut=StdIn.readLine();
        StdOut.println("ingrese el nombre ");
        String nombre=StdIn.readLine();
        StdOut.println("ingrese la direccion");
        String direccion=StdIn.readLine();
       int edad= verificacionNumerica("ingrese la edad");
        StdOut.println("ingrese la unidad de trabajo ");
        String unidad=StdIn.readLine();
        StdOut.println("ingrese las asignaturas impartidas (EJEMPLO: lenguaje/ingles/historia)");
        String asignatura=StdIn.readLine();

         sistema.agregarDocente(rut,nombre,direccion,edad,unidad,asignatura);

        StdOut.println("se ah agregado con exito");

    }


    public static void agregarfuncionario(ISistemaClase10 sistema){

        StdOut.println("ingrese el rut");
        String rut=StdIn.readLine();
        StdOut.println("ingrese el nombre ");
        String nombre=StdIn.readLine();
        StdOut.println("ingrese la direccion");
        String direccion=StdIn.readLine();
        int edad= verificacionNumerica("ingrese la edad");
        int horasTrabajada=verificacionNumerica("ingrese la cantidad de horas");
        StdOut.println("ingrese los dias trabajado (EJEMPLO: LUNES/MARTES/MIERCOLES)");
        String diasTrabajado=StdIn.readLine();


        sistema.agregarFuncionarios(rut,nombre,direccion,edad,horasTrabajada,diasTrabajado);

        StdOut.println("se ah agregado con exito");

    }

    public static void agregarEstudiante(ISistemaClase10 sistema){

        StdOut.println("ingrese el rut");
        String rut=StdIn.readLine();
        StdOut.println("ingrese el nombre ");
        String nombre=StdIn.readLine();
        StdOut.println("ingrese la direccion");
        String direccion=StdIn.readLine();
        int edad= verificacionNumerica("ingrese la edad");
        StdOut.println("ingrese la carrera");
        String carrera=StdIn.readLine();
        int anioIngreso=verificacionNumerica("ingrese anio de ingreso");
        sistema.agregarEstudiante(rut,nombre,direccion,edad,carrera,anioIngreso);

        StdOut.println("se ah agregado con exito");

    }








    public static int verificacionNumerica (String frace){

        while (true){

            StdOut.println(frace);
            String edadComoString=StdIn.readLine();

            if (esNumerico(edadComoString)){

                return Integer.parseInt(edadComoString);
            }
        }
    }

    public static boolean esNumerico(String edadComoString){

        try {
            Integer.parseInt(edadComoString);
            return true;
        }catch (NumberFormatException exception){
            StdOut.println("lo ingresado como ::::"+ edadComoString+"::::::: no es un factor numerico");
        }
        return false;
    }

}
