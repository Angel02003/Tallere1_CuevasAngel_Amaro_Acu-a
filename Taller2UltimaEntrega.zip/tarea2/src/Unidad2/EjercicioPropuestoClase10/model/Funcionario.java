package Unidad2.EjercicioPropuestoClase10.model;

public class Funcionario extends Persona{

       private int horasTrabajadas;
       private String diasTrabajado;

    public Funcionario(String rut, String nombre, String direccion, int edad, int horasTrabajadas, String diasTrabajado) {
        super(rut, nombre, direccion, edad);
        this.horasTrabajadas = horasTrabajadas;
        this.diasTrabajado = diasTrabajado;
    }

    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public String getDiasTrabajado() {
        return diasTrabajado;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public void setDiasTrabajado(String diasTrabajado) {
        this.diasTrabajado = diasTrabajado;
    }


    @Override
    public String listarPersonas() {
        return "//////////////// El Funcionario //////////// "+"\n"+
                "el rut del Funcionario es "+ this.getRut()+ "\n"+
                "el nombre del Funcionarioe es "+this.getNombre()+"\n"+
                "la direccion del Funcionario es "+ this.getDireccion()+"\n"+
                "la edad del Funcionario es "+this.getEdad()+"\n"+
                "las horas de Funcionario es "+ this.getHorasTrabajadas()+"\n"+
                "los dias a trabajar son "+this.getDiasTrabajado();
    }
}
