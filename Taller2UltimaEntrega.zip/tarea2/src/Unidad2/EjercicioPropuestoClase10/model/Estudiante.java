package Unidad2.EjercicioPropuestoClase10.model;

import Unidad2.Ejercicio100.Model.Model.Personas;

public class Estudiante extends Persona {


    private String carrera;
    private int anioDeIngreso;

    public Estudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso) {
        super(rut, nombre, direccion, edad);
        this.carrera = carrera;
        this.anioDeIngreso = anioDeIngreso;
    }

    public String getCarrera() {
        return carrera;
    }

    public int getAnioDeIngreso() {
        return anioDeIngreso;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public void setAnioDeIngreso(int anioDeIngreso) {
        this.anioDeIngreso = anioDeIngreso;
    }


    @Override
    public String listarPersonas() {
        return "//////////////// El estudiante //////////// "+"\n"+
                "el rut del estudiante es "+ this.getRut()+ "\n"+
                "el nombre de lestudiante es "+this.getNombre()+"\n"+
                "la direccion del estudiante es "+ this.getDireccion()+"\n"+
                "la edad del estudiante es "+this.getEdad()+"\n"+
                "la carrera del estudiante es "+this.getCarrera()+
                "el anio de ingreso es "+ this.anioDeIngreso+"\n";
    }
}
