package Unidad2.EjercicioPropuestoClase10.model;

public class Docente extends Persona{
    private String unidadTrabajada;
    private String nombreDeLasCarreras;

    public Docente(String rut, String nombre, String direccion, int edad, String unidadTrabajada, String nombreDeLasCarreras) {
        super(rut, nombre, direccion, edad);
        this.unidadTrabajada = unidadTrabajada;
        this.nombreDeLasCarreras = nombreDeLasCarreras;
    }

    public String getUnidadTrabajada() {
        return unidadTrabajada;
    }

    public String getNombreDeLasCarreras() {
        return nombreDeLasCarreras;
    }

    public void setUnidadTrabajada(String unidadTrabajada) {
        this.unidadTrabajada = unidadTrabajada;
    }

    public void setNombreDeLasCarreras(String nombreDeLasCarreras) {
        this.nombreDeLasCarreras = nombreDeLasCarreras;
    }


    @Override
    public String listarPersonas() {
        return "//////////////// El Docente //////////// "+"\n"+
                "el rut del Docente es "+ this.getRut()+ "\n"+
                "el nombre del Docente es "+this.getNombre()+"\n"+
                "la direccion del Docente es "+ this.getDireccion()+"\n"+
                "la edad del Docente es "+this.getEdad()+"\n"+
                "la unidad de tranajo es "+ this.getUnidadTrabajada()+
                "el nombre de la carrera es "+ this.getNombreDeLasCarreras();
    }
}
