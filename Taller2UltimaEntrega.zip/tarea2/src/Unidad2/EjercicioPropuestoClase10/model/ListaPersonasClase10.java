package Unidad2.EjercicioPropuestoClase10.model;

public class ListaPersonasClase10 {


    private Persona[] arregloPersonas;
    private int cantidadMaximaPersonas;
    private int cantidadaActualPersonas;


    public ListaPersonasClase10(int cantidadMaximaPersonas) {


        this.cantidadMaximaPersonas = cantidadMaximaPersonas;
        this.arregloPersonas = new Persona[cantidadMaximaPersonas];
        this.cantidadaActualPersonas = 0;
    }


    public int buscar(String rut) {

        for (int i = 0; i < this.cantidadaActualPersonas; i++) {

            if (this.arregloPersonas[i].getRut().equalsIgnoreCase(rut)) {
                return i;
            }

        }
        return -1;
    }


    public Persona optener(int pocicion){

       return this.arregloPersonas[pocicion];
    }

    public boolean agregarPersona(Persona nuevaPersona){


        this.arregloPersonas[this.cantidadaActualPersonas]=nuevaPersona;
        this.cantidadaActualPersonas++;
        return true;
    }

    public boolean eliminar(String rut){

        int eliminar=this.buscar(rut);
        if (eliminar<=0){
            for (int i = 0; i < this.cantidadaActualPersonas-1; i++) {

                this.arregloPersonas[i]=this.arregloPersonas[i+1];
            }
            this.cantidadaActualPersonas--;
            return true;
        }
        return false;
    }

    public int getCantidadMaximaPersonas() {
        return cantidadMaximaPersonas;
    }

    public int getCantidadaActualPersonas() {
        return cantidadaActualPersonas;
    }
}
