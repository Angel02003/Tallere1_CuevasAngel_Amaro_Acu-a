package Unidad2.Ejercicio11;

import Unidad2.Ejercicio11.Servis.IsistemaPorteria;
import Unidad2.Ejercicio11.Util.Instalador;
import ucn.StdIn;
import ucn.StdOut;

import java.io.IOException;

public class Main11 {
    public static void main(String[] args) throws IOException {
       configuracion();


    }


    public static void configuracion() throws IOException {

        IsistemaPorteria sistema=new Instalador().isntalarSistema();
        String listado="listadoCartas.txt";

        boolean lecturaDeCartas=sistema.inicarSistema(listado);

        menuPricipal(sistema);

    }


    public static void menuPricipal(IsistemaPorteria sistema) {

        while (true) {

            StdOut.println("[1] para listar todas las cartas");
            StdOut.println("[2] para listar entidades");
            StdOut.println("[3] para listar solo las destrezas");
            String opccion = StdIn.readLine();

            if (opccion.equalsIgnoreCase("1")) {
       listarTodasLasCartas(sistema);
            }
            if (opccion.equalsIgnoreCase("2")) {
listarentidad(sistema);
            }

            if (opccion.equalsIgnoreCase("3")) {
listarDestreza(sistema);
            }


        }


    }

    public static void listarTodasLasCartas(IsistemaPorteria sistema){



        String respuesta="";


        respuesta=sistema.listarCartas();

        StdOut.println(respuesta);
    }



    public static void  listarDestreza(IsistemaPorteria sistema){
        String respuesta=";";

        respuesta=sistema.listarDestrezas();
        StdOut.println(respuesta);
    }

    public static void  listarentidad(IsistemaPorteria sistema){
        String respuesta=";";

        respuesta=sistema.listarEntidades();
        StdOut.println(respuesta);
    }

}
