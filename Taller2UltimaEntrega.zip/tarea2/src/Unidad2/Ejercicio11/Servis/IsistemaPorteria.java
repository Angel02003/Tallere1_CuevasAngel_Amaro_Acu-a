package Unidad2.Ejercicio11.Servis;

import java.io.IOException;

public interface IsistemaPorteria {

    boolean inicarSistema(String listadoCartas) throws IOException;
    String listarCartas();
    String listarEntidades();
    String listarDestrezas();




}
