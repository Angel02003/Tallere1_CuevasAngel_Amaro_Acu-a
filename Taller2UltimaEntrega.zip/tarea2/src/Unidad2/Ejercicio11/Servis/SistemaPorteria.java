package Unidad2.Ejercicio11.Servis;

import Unidad2.Ejercicio11.model.Carta;
import Unidad2.Ejercicio11.model.Destresa;
import Unidad2.Ejercicio11.model.Entidad;
import Unidad2.Ejercicio11.model.ListaCarta;
import ucn.ArchivoEntrada;
import ucn.Registro;
import ucn.StdOut;

import java.io.IOException;

public class SistemaPorteria implements IsistemaPorteria{


    private ListaCarta listaCarta;

    public SistemaPorteria(){
        listaCarta=new ListaCarta(999);
    }



     //todo: va el nombre de la lista (String listado cartas)

    @Override
    public boolean inicarSistema(String listadoCartas) throws IOException {

        ArchivoEntrada archivo1 = new ArchivoEntrada(listadoCartas);

        while (!archivo1.isEndFile()) {
            Registro registro = archivo1.getRegistro();
            String instancia = registro.getString();
            String nombre = registro.getString();
            String presencia = registro.getString();
            String nivel = registro.getString();
            String descripccion = registro.getString();

            if (instancia.equalsIgnoreCase("destreza")) {
                String potencia = registro.getString();
                String precicion = registro.getString();

                Destresa destresa = new Destresa(instancia, nombre, presencia, nivel, descripccion, potencia, precicion);

                this.listaCarta.agragarCarta(destresa);
            }
            if (instancia.equalsIgnoreCase("Entidad")) {

                String poderFisico = registro.getString();
                String poderMagico = registro.getString();
                String resistenciaFisica = registro.getString();
                String resistenciaMagica = registro.getString();

                Entidad entidad = new Entidad(instancia, nombre, presencia, nivel, descripccion, poderMagico, poderFisico, resistenciaMagica, resistenciaFisica);

                this.listaCarta.agragarCarta(entidad);

            }
        }
            archivo1.close();
            return true;

    }



    @Override
    public String listarCartas() {

            String imprimirCartas = "";

            for (int i = 0; i < 20; i++) {

            imprimirCartas += this.listaCarta.optenerCarta(i).empaquetarInformacion();
            imprimirCartas += "\n";
        }
        for (int i = 0; i > 20; i++) {
            imprimirCartas += this.listaCarta.optenerCarta(i).empaquetarInformacion();
            imprimirCartas += "\n";
        }
        return imprimirCartas;
    }

    @Override
    public String listarEntidades() {
        String imprimirEntidades = "";

        for (int i = 0; i < 20; i++) {
            imprimirEntidades += this.listaCarta.optenerCarta(i).empaquetarInformacion();
            imprimirEntidades += "\n";
        }
        return imprimirEntidades;
    }

    @Override
    public String listarDestrezas() {


        String imprimirDestrezas = "";

        for (int i = 0; i < 20; i++) {
            imprimirDestrezas += this.listaCarta.optenerCarta(i).empaquetarInformacion();
            imprimirDestrezas += "\n";
        }
        return imprimirDestrezas;
    }







    public boolean estaVacia(){

        if (listaCarta.getCantidadActual()==0){
            return true;
        }
        else {
            StdOut.println("la lista esta vacia");
            return false;
        }


    }





}
