package Unidad2.Ejercicio11.model;

import ucn.In;

public class ListaCarta {


    private Carta[] arregloCarta;
    private int cantidadMaxima;
    private  int cantidadActual;


    public ListaCarta (int cantidadMaxima){

        if (cantidadMaxima<=0){
            throw new IllegalArgumentException("la cantidad Maxima de la lista no puede ser menor igual a 0 ");
        }

        this.cantidadMaxima=cantidadMaxima;
        this.arregloCarta=new Carta[cantidadMaxima];
        this.cantidadActual=0;
    }




    public int buscarCarta(String nombre){

        for (int i = 0; i < this.cantidadActual; i++) {
            if (this.arregloCarta[i].getNombre().equalsIgnoreCase(nombre)){
                return i;
            }
        }
        return -1;
    }


    public Carta optenerCarta(int pocicion){

        if (pocicion<0 || pocicion>=this.cantidadMaxima){
            throw new IllegalArgumentException(" la pocicion no fue encontrada");
        }

        return this.arregloCarta[pocicion];

    }



    public boolean  agragarCarta (Carta nuevacarta){


        this.arregloCarta[this.cantidadActual]=nuevacarta;
        this.cantidadActual++;
        return true;
    }

    public void lecturaDeArchivo(String nombreArchivo) {

        Carta carta;


        In archivoEntrada = new In(nombreArchivo);


        while (!nombreArchivo.isEmpty()) {

            String[] linea2 = archivoEntrada.readLine().split(",");

            String nombre = linea2[0];
            String presencia = linea2[1];
            String nivel = linea2[2];
            String descripccion = linea2[3];




           // todo: falta guardar la clase carta
            //  todo : 1) crear una carta=new Carta(parametros)
            // todo: 2) this.agregarCarta(carta)


        }
        archivoEntrada.close();

    }


        public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}
