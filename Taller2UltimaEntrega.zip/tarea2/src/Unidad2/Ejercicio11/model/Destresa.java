package Unidad2.Ejercicio11.model;

public class Destresa extends  Carta{



    private String potencia;
    private String precicion;

    private String instancia;

    public Destresa(String instancia,String nombre, String presenia, String nivel, String descripccion, String potencia, String precicion) {
        super(nombre, presenia, nivel, descripccion);
        this.potencia = potencia;
        this.precicion = precicion;
        this.instancia = instancia;
    }

    //--------------------------------------------------------------------------------------------------------------------------------


    public String getPotencia() {
        return potencia;
    }

    public String getPrecicion() {
        return precicion;
    }

    public String getInstancia() {
        return instancia;
    }
    //--------------------------------------------------------------------------------------------------------------------------------


    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public void setPrecicion(String precicion) {

        this.precicion = precicion;
    }

    public void setInstancia(String instancia) {
        this.instancia = instancia;
    }

    @Override
    public boolean esdetipoInstancia() {
        if (instancia.equalsIgnoreCase("Destreza")){
            return true;
        }
        return false;
    }


    @Override
    public String empaquetarInformacion() {
        return  "-----------------------  Destrezas  ---------------------------------"+
                "la instancia es "+this.instancia+"\n"+
                " el nombre de la carta es "+ this.getNombre()+"\n"+
                " la presencia de la carta es "+ this.getPresenia()+"\n"+
                " el nivel de la carta es "+ this.getNivel() +"\n"+
                " la descripccion de la carta es "+ this.getDescripccion()+"\n"+
                " la potencia  de la carta es  "+ this.potencia+"\n"+
                " la precicion de la carta es "+"\n";
    }


    //--------------------------------------------------------------------------------------------------------------------------------


}
