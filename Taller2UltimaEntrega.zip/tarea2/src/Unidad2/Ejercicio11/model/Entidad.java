package Unidad2.Ejercicio11.model;

public class Entidad  extends Carta{

    private String poderMagico;
    private String poderFisico;
    private String resistenciaMagica;
    private String resistenciaFisica;
    private String instancia;

    public Entidad(String instancia,String nombre, String presenia, String nivel, String descripccion, String poderMagico, String poderFisico, String resistenciaMagica, String resistenciaFisica) {
        super(nombre, presenia, nivel, descripccion);
        this.poderMagico = poderMagico;
        this.poderFisico = poderFisico;
        this.resistenciaMagica = resistenciaMagica;
        this.resistenciaFisica = resistenciaFisica;
        this.instancia = instancia;
    }


//--------------------------------------------------------------------------------------------------------------------------------

    public String getPoderMagico() {
        return poderMagico;
    }

    public String getPoderFisico() {
        return poderFisico;
    }

    public String getResistenciaMagica() {
        return resistenciaMagica;
    }

    public String getResistenciaFisica() {
        return resistenciaFisica;
    }

    public String getInstancia() {
        return instancia;
    }
    //--------------------------------------------------------------------------------------------------------------------------------


    public void setPoderMagico(String poderMagico) {
        this.poderMagico = poderMagico;
    }

    public void setPoderFisico(String poderFisico) {
        this.poderFisico = poderFisico;
    }

    public void setResistenciaMagica(String resistenciaMagica) {
        this.resistenciaMagica = resistenciaMagica;
    }

    public void setResistenciaFisica(String resistenciaFisica) {
        this.resistenciaFisica = resistenciaFisica;
    }

    public void setInstancia(String instancia) {
        this.instancia = instancia;
    }

    @Override
    public boolean esdetipoInstancia() {

        if (this.instancia.equalsIgnoreCase("entidad")){
            return true;
        }
        return false;
    }

    @Override
    public String empaquetarInformacion() {
        return "-------------------------- las entidades son ---------------------"+"\n"+
                "la instancia es "+ this.getInstancia()+"\n"+
                "el nombre es "+ this.getNombre()+"\n"+
                "la precensia es " +this.getPresenia()+"\n"+
                "el nivel es "+ this.getNivel()+"\n"+
                "la descripccion es "+ this.getDescripccion()+"\n"+
                "el poder magico es "+ this.getPoderMagico()+"\n"+
                "el poder fisico es "+ this.getPoderFisico()+
                "la resistencia magica es "+ this.getResistenciaMagica()+"\n"+
                "la resistencia fisia es "+ this.getResistenciaFisica()+"\n";
    }
    //--------------------------------------------------------------------------------------------------------------------------------




    //--------------------------------------------------------------------------------------------------------------------------------


}
