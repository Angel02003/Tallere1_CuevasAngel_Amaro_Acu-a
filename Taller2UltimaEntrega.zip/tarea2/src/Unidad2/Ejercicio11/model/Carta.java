package Unidad2.Ejercicio11.model;

public  abstract  class Carta {

    private String nombre;
    private String presenia;
    private String nivel;
    private String descripccion;

    public Carta(String nombre, String presenia, String nivel, String descripccion) {
        this.nombre = nombre;
        this.presenia = presenia;
        this.nivel = nivel;
        this.descripccion = descripccion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPresenia() {
        return presenia;
    }

    public String getNivel() {
        return nivel;
    }

    public String getDescripccion() {
        return descripccion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPresenia(String presenia) {
        this.presenia = presenia;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public void setDescripccion(String descripccion) {
        this.descripccion = descripccion;
    }




    public abstract boolean esdetipoInstancia();


    public abstract String empaquetarInformacion();

}
