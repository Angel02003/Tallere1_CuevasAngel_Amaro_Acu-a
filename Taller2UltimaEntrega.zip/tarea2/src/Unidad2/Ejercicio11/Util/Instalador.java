package Unidad2.Ejercicio11.Util;

import Unidad2.Ejercicio11.Servis.IsistemaPorteria;
import Unidad2.Ejercicio11.Servis.SistemaPorteria;

public class Instalador {


   private IsistemaPorteria sistemaPorteria;


   public Instalador(){
       this.sistemaPorteria=new SistemaPorteria();
   }

   public IsistemaPorteria isntalarSistema(){
       return this.sistemaPorteria;
   }




}
