package Unidad2.Ejercicio100.Model;

import Unidad2.Ejercicio100.Model.Servis.ISistemaPorteria;
import Unidad2.Ejercicio100.Model.Servis.Sistema;
import Unidad2.Ejercicio100.Model.Util.Instalador;
import ucn.StdIn;
import ucn.StdOut;

public class Ejercicio100 {
    public static void main(String[]args){


     configuracion();
    }


    public static void  configuracion(){

        ISistemaPorteria  Sistema =new Instalador().instalarSistema();

        memuPrincipal(Sistema);


    }

    public static void  memuPrincipal(ISistemaPorteria sistema){

        while (true) {

            StdOut.println("//////////////  bienvenido al menu principal  //////////////");
            StdOut.println("/////////////   ingrese una de las opcciones  ///////");
            StdOut.println("[1] para bucar a la persona ");
            StdOut.println("[2] para listar a las personas");
            StdOut.println("[3] para agregar a una persona ");
            StdOut.println("[4] para salir ");
            String opcion = StdIn.readLine();

            if (opcion.equalsIgnoreCase("1")) {
              buscar(sistema);
            }
            if (opcion.equalsIgnoreCase("2")) {
              listar(sistema);
            }
            if (opcion.equalsIgnoreCase("3")) {
             segundoMemu(sistema);
            }
            if (opcion.equalsIgnoreCase("4")) {
                break;
            }
        }
        StdOut.println(" adios usuario ");



    }




    public static void buscar(ISistemaPorteria sistema){

        String respuesta=";";

        StdOut.println("ingrese el rut ah buscar");
        String rut=StdIn.readLine();

        respuesta=sistema.buscar(rut);

        StdOut.println(respuesta);

    }


    public static void listar(ISistemaPorteria sistema){

        String listado="";

        listado=sistema.listar();;
        StdOut.println(listado);


    }



    public static void segundoMemu(ISistemaPorteria sistema){


        while (true){


            StdOut.println("ingrese a la persona que quiere agregar");
            StdOut.println("[1] para Estudiante");
            StdOut.println("[2] para docente");
            StdOut.println("[3] para funcionario");
            StdOut.println("[4] para regresar al menu anterior");
            String opccion=StdIn.readLine();

            if (opccion.equalsIgnoreCase("1")){
                Estudiante(sistema);
            }
            if (opccion.equalsIgnoreCase("2")){
             agregarDocente(sistema);
            }
            if (opccion.equalsIgnoreCase("3")){
              agregarFuncionario(sistema);
            }
            if (opccion.equalsIgnoreCase("4")){
               break;
            }
        }
    }

    public static void Estudiante(ISistemaPorteria sistemaPorteria){

        StdOut.println("ingrese el rut del estudiante");
        String rut=StdIn.readLine();
        StdOut.println("ingrese el nombre del estudinate");
        String nombre=StdIn.readLine();
        StdOut.println("ingrese la direccion del estudiante");
        String direccion=StdIn.readLine();

        int edad=esnumerico("ingrese la edad ");
        StdOut.println("ingrese su carrera ");
        String carrera=StdIn.readLine();
        StdOut.println("ingrese  su anio de ingreso");
        int anioIngreso=esnumerico("ingrese el anio de ingreso");


        sistemaPorteria.agregarEstudiante(rut,nombre,direccion,edad,carrera,anioIngreso);

        StdOut.println("se ah agregado con exito");
    }





    public static void  agregarDocente(ISistemaPorteria sistema){
        StdOut.println("ingrese el rut del estudiante");
        String rut=StdIn.readLine();
        StdOut.println("ingrese el nombre del estudinate");
        String nombre=StdIn.readLine();
        StdOut.println("ingrese la direccion del estudiante");
        String direccion=StdIn.readLine();
        StdOut.println("ingrese la edad de estudiante");
        int edad=esnumerico("ingrese la edad ");
        StdOut.println("ingrese la unidad a la que trabaja ");
        String unidadTrabajada=StdIn.readLine();
        StdOut.println("ingresa las materias que aplica (Ejemplo: matematica/historia/religion etc)");
        String materias=StdIn.readLine();

        sistema.agregarDocente(rut,nombre,direccion,edad,unidadTrabajada,materias);

        StdOut.println("el docente se ah agregado con exito");

    }


    public static void agregarFuncionario (ISistemaPorteria sistema){

        StdOut.println("ingrese el rut del estudiante");
        String rut=StdIn.readLine();
        StdOut.println("ingrese el nombre del estudinate");
        String nombre=StdIn.readLine();
        StdOut.println("ingrese la direccion del estudiante");
        String direccion=StdIn.readLine();
        StdOut.println("ingrese la edad de estudiante");
        int edad=esnumerico("ingrese la edad ");
        int cantidadHoras=esnumerico("ingrese la cantidad de horas");
        StdOut.println("listado de los dias trabajado (EJEMPLO: LUNES/MARTES/Viernes)");
        String dias=StdIn.readLine();


        sistema.agregarFuncionario(rut,nombre,direccion,edad,dias,cantidadHoras);

        StdOut.println("se ah ingresado con exito");
    }



    public static int esnumerico(String frace){

        String esNumerico;

        while (true) {

            StdOut.println(frace);
            esNumerico=StdIn.readLine();

            try {
                 Integer.parseInt(esNumerico);
            }
            catch (NumberFormatException exception){
                StdOut.println("lo lamento pero el valor no es numerico");
            }
        }
    }

}
