package Unidad2.Ejercicio100.Model.Servis;

public interface ISistemaPorteria {

       // todo:LecturaDeArchivo (boolean inicarSistema(String listadoCartas) throws IOException;)
    boolean agregarEstudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso);
    boolean agregarDocente(String rut, String nombre, String direccion, int edad, String unidadTrabajar, String asignaturasImpartidas);
    boolean agregarFuncionario(String rut, String nombre, String direccion, int edad, String diasTrabajadoALaSemana, int horasTrabajads);

    String buscar(String rut);
    String listar();

}
