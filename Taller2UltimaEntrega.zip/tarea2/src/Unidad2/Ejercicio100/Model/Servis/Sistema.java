package Unidad2.Ejercicio100.Model.Servis;

import Unidad2.Ejercicio100.Model.Model.*;
import Unidad2.Ejercicio11.model.Destresa;
import Unidad2.Ejercicio11.model.Entidad;
import ucn.ArchivoEntrada;
import ucn.Registro;

import java.io.IOException;

public class Sistema implements ISistemaPorteria{

    ListaPersonas100 lista100;

    public Sistema(){lista100=new ListaPersonas100(9999);}


    @Override
    public boolean agregarEstudiante(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso) {
        return agregar(new Estudiantes100(rut,nombre,direccion,edad,carrera,anioDeIngreso));
    }

    @Override
    public boolean agregarDocente(String rut, String nombre, String direccion, int edad, String unidadTrabajar, String asignaturasImpartidas) {
        return agregar(new Docente100(rut,nombre,direccion,edad,unidadTrabajar,asignaturasImpartidas));
    }

    @Override
    public boolean agregarFuncionario(String rut, String nombre, String direccion, int edad, String diasTrabajadoALaSemana, int horasTrabajads) {
        return agregar(new Funcionarios(rut,nombre,direccion,edad,diasTrabajadoALaSemana,horasTrabajads));
    }


    @Override
    public String buscar(String rut) {

        Personas personas;

        if (estaVacia()){
            return "la lista esta vacia";
        }
        for (int i = 0; i < lista100.getCantidadActual(); i++) {

            personas=lista100.optener(i);
            return personas.desplegar();

        }
        return "la persona no fue encontrada";
    }

    @Override
    public String listar() {
        // todo se llama a la clase persona
        Personas personas;
        String respuesta="";
        if (estaVacia()){
            return "la lista esta vacia";
        }


        for (int i = 0; i <lista100.getCantidadActual() ; i++) {

            personas= lista100.optener(i);
            respuesta+=personas.desplegar();
        }

        return respuesta;
    }


    public boolean agregar(Personas nuevaPersona){
        return lista100.agregar(nuevaPersona);
    }




    public boolean estaVacia(){

        if (lista100.getCantidadActual()==0){
            return true;
        }
        return false;
    }

    // todo: va el nombre de la lista (String listado cartas)

   // public boolean lecturaArchivo(String listadoCartas) throws IOException {

     //   ArchivoEntrada archivo1=new ArchivoEntrada(listadoCartas);

       // while (!archivo1.isEndFile()){
         //   Registro registro=archivo1.getRegistro();
           // String instancia=registro.getString();
        //    String nombre=registro.getString();
          //  String presencia=registro.getString();
           // String nivel=registro.getString();
           // String descripccion=registro.getString();

            //if (instancia.equalsIgnoreCase("destreza")){
              //String precicion=registro.getString();

               // Destresa destresa=new Destresa(instancia,nombre,presencia,nivel,descripccion,potencia,precicion);

                //this.listaCarta.agragarCarta(destresa);
            //}
            //if (instancia.equalsIgnoreCase("Entidad")){

               // String poderFisico=registro.getString();
                //String poderMagico=registro.getString();
                //String resistenciaFisica=registro.getString();
                //String resistenciaMagica=registro.getString();

               //Entidad entidad=new Entidad(instancia,nombre,presencia,nivel,descripccion,poderMagico,poderFisico,resistenciaMagica,resistenciaFisica);

                //this.listaCarta.agragarCarta(entidad);
            //}
       // }
        //archivo1.close();
        //return true;
    //}


}
