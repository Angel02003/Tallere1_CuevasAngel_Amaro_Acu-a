package Unidad2.Ejercicio100.Model.Model;

public class Docente100 extends Personas{

    private String unidadTrabajar;
    private String asignaturasImpartidas;

    public Docente100(String rut, String nombre, String direccion, int edad, String unidadTrabajar, String asignaturasImpartidas) {
        super(rut, nombre, direccion, edad);
        this.unidadTrabajar = unidadTrabajar;
        this.asignaturasImpartidas = asignaturasImpartidas;
    }

    public String getUnidadTrabajar() {
        return unidadTrabajar;
    }

    public String getAsignaturasImpartidas() {
        return asignaturasImpartidas;
    }

    public void setUnidadTrabajar(String unidadTrabajar) {
        this.unidadTrabajar = unidadTrabajar;
    }

    public void setAsignaturasImpartidas(String asignaturasImpartidas) {
        this.asignaturasImpartidas = asignaturasImpartidas;
    }

    @Override
    public String desplegar() {
        return   "--------------- Docentes ------------"+"\n"+
                "el rut es "+this.getRut()+"\n"+
                " el nombre es "+ this.getNombre()+"\n"+
                " la direccion es "+ this.getDireccion()+"\n"+
                " la edad es "+ this.getEdad()+"\n"+
                " la inidad de trabajo es "+ this.getUnidadTrabajar()+"\n"+
                " las asignaturas impartidas son "+ this.asignaturasImpartidas+"\n";
    }
}
