package Unidad2.Ejercicio100.Model.Model;

public class Estudiantes100 extends Personas{


    private String carrera;
    private int anioDeIngreso;

    public Estudiantes100(String rut, String nombre, String direccion, int edad, String carrera, int anioDeIngreso) {
        super(rut, nombre, direccion, edad);
        this.carrera = carrera;
        this.anioDeIngreso = anioDeIngreso;
    }

    public String getCarrera() {
        return carrera;
    }

    public int getAnioDeIngreso() {
        return anioDeIngreso;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public void setAnioDeIngreso(int anioDeIngreso) {
        this.anioDeIngreso = anioDeIngreso;
    }


    @Override
    public String desplegar() {
        return "------------ Estudiantes ---------"+"\n"+
                " el rut es  " + this.getRut()+"\n"+
                "el nombre es "+ this.getNombre()+"\n"+
                " la direccion es "+ this.getDireccion()+"\n"+
                " la carrera es "+ this.getCarrera()+"\n"+
                "el anio e ingreso es "+ this.anioDeIngreso+"\n";
    }
}
