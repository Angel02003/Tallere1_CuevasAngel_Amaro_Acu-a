package Unidad2.Ejercicio100.Model.Model;

public class Funcionarios extends Personas{

    private String diasTrabajadoALaSemana;
    private int horasTrabajads;

    public Funcionarios(String rut, String nombre, String direccion, int edad, String diasTrabajadoALaSemana, int horasTrabajads) {
        super(rut, nombre, direccion, edad);
        this.diasTrabajadoALaSemana = diasTrabajadoALaSemana;
        this.horasTrabajads = horasTrabajads;
    }
    //-----------------------------------------------------------------------------------------------------------------
    public String getDiasTrabajadoALaSemana() {
        return diasTrabajadoALaSemana;
    }

    public int getHorasTrabajads() {
        return horasTrabajads;
    }
//----------------------------------------------------------------------------------------------------------------------
    public void setDiasTrabajadoALaSemana(String diasTrabajadoALaSemana) {
        this.diasTrabajadoALaSemana = diasTrabajadoALaSemana;
    }

    public void setHorasTrabajads(int horasTrabajads) {
        this.horasTrabajads = horasTrabajads;
    }


    @Override
    public String desplegar() {
        return  " ---------------- Funcionarios----------"+"\n"+
                " el rut es "+ this.getRut()+"\n"+
                " el nombre es "+ this.getNombre()+"\n"+
                " la direccion es  "+ this.getDireccion()+"\n"+
                " la edad es "+ this.getEdad()+"\n"+
                " los dias trabajados son "+this.diasTrabajadoALaSemana+"\n"+
                " la cantidad De horas es "+ this.horasTrabajads+"\n";
    }
}
