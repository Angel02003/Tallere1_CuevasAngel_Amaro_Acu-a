package Unidad2.Ejercicio100.Model.Util;

import Unidad2.Ejercicio100.Model.Servis.ISistemaPorteria;
import Unidad2.Ejercicio100.Model.Servis.Sistema;

public class Instalador {

    ISistemaPorteria Sistema;
    public Instalador () {Sistema=new Sistema();}
    public ISistemaPorteria instalarSistema(){return this.Sistema;}


}
